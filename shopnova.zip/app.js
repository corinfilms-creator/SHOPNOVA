const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
app.set('view engine','ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({extended:true}));

mongoose.connect('mongodb://127.0.0.1:27017/shopnova');

app.get('/', (req,res)=> res.render('index'));

app.listen(3000, ()=> console.log('Running on http://localhost:3000'));
